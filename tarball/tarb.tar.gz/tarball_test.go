package tarball

import (
	// "io/ioutil"
	// "os"
	"testing"
)

func TestRealCompress(t *testing.T) {
	f, err := world.Create("../foo.tar.gz")
	if err != nil {
		t.Fatal(err)
	}
	// defer os.Remove("foo.tar.gz")

	if err := Compress(".", f); err != nil {
		t.Fatal(err)
	}
}

// func TestRealExtract(t *testing.T) {
// 	dir, err := ioutil.TempDir("", "extract")
// 	if err != nil {
// 		t.Fatal(err)
// 	}
// 	defer os.RemoveAll(dir)

// 	if err := Extract("../foo.tar.gz", dir); err != nil {
// 		t.Fatal(err)
// 	}
// }
